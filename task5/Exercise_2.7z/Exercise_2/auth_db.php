<?php
class AuthDB {
    private $conn;
    private $config;
    private $connected = false;
    
    public function __construct(array $dbConfig = []) {
        $defaultConfig = [
            'host' => 'localhost',
            'dbname' => 'library_system',
            'username' => 'root',
            'password' => '',
            'charset' => 'utf8mb4',
            'port' => 3306,
            'options' => [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_PERSISTENT => false
            ]
        ];
        
        $this->config = array_merge($defaultConfig, $dbConfig);
        $this->connect();
    }
    
    private function connect() {
        if ($this->connected) {
            return true;
        }

        try {
            $dsn = "mysql:host={$this->config['host']};port={$this->config['port']};dbname={$this->config['dbname']};charset={$this->config['charset']}";
            
            $this->conn = new PDO(
                $dsn, 
                $this->config['username'], 
                $this->config['password'],
                $this->config['options']
            );
            
            $this->connected = true;
            return true;
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            throw new RuntimeException("Database connection error. Please try again later.");
        }
    }

    // User Registration Methods
    public function checkUserExists($username, $email) {
        $this->ensureConnection();
        
        try {
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1");
            $stmt->execute([$username, $email]);
            return (bool)$stmt->fetch();
        } catch (PDOException $e) {
            error_log("Error checking user existence: " . $e->getMessage());
            throw new RuntimeException("Error checking user existence.");
        }
    }

    public function registerUser($username, $email, $password, $fullName = null) {
        $this->ensureConnection();
        
        try {
            if ($this->checkUserExists($username, $email)) {
                throw new RuntimeException("Username or email already exists");
            }

            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $fullName = $fullName ?: $username;
            
            $stmt = $this->conn->prepare("
                INSERT INTO users 
                (username, email, password_hash, full_name, role, status, created_at, updated_at) 
                VALUES (?, ?, ?, ?, 'member', 'active', NOW(), NOW())
            ");
            
            $success = $stmt->execute([$username, $email, $hashedPassword, $fullName]);
            
            if (!$success) {
                throw new RuntimeException("Failed to register user");
            }
            
            return $this->conn->lastInsertId();
        } catch (PDOException $e) {
            error_log("Registration error: " . $e->getMessage());
            throw new RuntimeException("Registration failed. Please try again.");
        }
    }

    // Google Auth Methods
    public function getUserByGoogleId($googleId) {
        $this->ensureConnection();
        
        try {
            $stmt = $this->conn->prepare("SELECT * FROM users WHERE google_id = ? LIMIT 1");
            $stmt->execute([$googleId]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("Error getting user by Google ID: " . $e->getMessage());
            throw new RuntimeException("Error retrieving user information.");
        }
    }

    public function getUserByEmail($email) {
        $this->ensureConnection();
        
        try {
            $stmt = $this->conn->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
            $stmt->execute([$email]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("Error getting user by email: " . $e->getMessage());
            throw new RuntimeException("Error retrieving user information.");
        }
    }

    public function createGoogleUser($username, $email, $googleId, $fullName = null) {
        $this->ensureConnection();
        
        try {
            if ($this->checkUserExists($username, $email)) {
                throw new RuntimeException("Username or email already exists");
            }

            $fullName = $fullName ?: $username;
            
            $stmt = $this->conn->prepare("
                INSERT INTO users 
                (username, email, google_id, full_name, role, status, created_at, updated_at) 
                VALUES (?, ?, ?, ?, 'member', 'active', NOW(), NOW())
            ");
            
            $success = $stmt->execute([$username, $email, $googleId, $fullName]);
            
            if (!$success) {
                throw new RuntimeException("Failed to create Google user");
            }
            
            return $this->conn->lastInsertId();
        } catch (PDOException $e) {
            error_log("Google user creation error: " . $e->getMessage());
            throw new RuntimeException("Google authentication failed. Please try again.");
        }
    }

    // Utility Methods
    public function generateUsername($name) {
        $username = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $name));
        if (empty($username)) {
            $username = 'user' . bin2hex(random_bytes(3));
        }
        
        // Ensure username is unique
        $baseUsername = $username;
        $counter = 1;
        
        while ($this->usernameExists($username)) {
            $username = $baseUsername . $counter;
            $counter++;
        }
        
        return $username;
    }

    private function usernameExists($username) {
        try {
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
            $stmt->execute([$username]);
            return (bool)$stmt->fetch();
        } catch (PDOException $e) {
            error_log("Error checking username existence: " . $e->getMessage());
            return false;
        }
    }

    public function isConnected() {
        return $this->connected;
    }

    public function getConnection() {
        $this->ensureConnection();
        return $this->conn;
    }

    private function ensureConnection() {
        if (!$this->connected) {
            throw new RuntimeException("No database connection available");
        }
    }
}
?>