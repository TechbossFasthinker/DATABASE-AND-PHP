<?php
/**
 * Simple Library System Database Setup
 * This version skips the problematic user_sessions table
 */

function quickLibrarySetup() {
    echo "🚀 Simple Library System Setup\n";
    echo str_repeat("=", 40) . "\n\n";
    
    // Configuration
    $config = [
        'host' => 'localhost',
        'username' => 'root',
        'password' => '',
        'port' => 3306,
        'dbname' => 'library_system'
    ];
    
    try {
        // Step 1: Create database
        echo "1. Creating database...\n";
        $dsn = "mysql:host={$config['host']};port={$config['port']};charset=utf8mb4";
        $pdo = new PDO($dsn, $config['username'], $config['password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
        
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$config['dbname']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        echo "   ✓ Database '{$config['dbname']}' created\n\n";
        
        // Step 2: Connect to database
        $dsn = "mysql:host={$config['host']};port={$config['port']};dbname={$config['dbname']};charset=utf8mb4";
        $pdo = new PDO($dsn, $config['username'], $config['password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
        
        // Step 3: Create tables
        echo "2. Creating tables...\n";
        
        // Users table
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            full_name VARCHAR(100) NOT NULL,
            role ENUM('admin', 'librarian', 'member') DEFAULT 'member',
            status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            last_login TIMESTAMP NULL,
            INDEX idx_username (username),
            INDEX idx_email (email),
            INDEX idx_role (role)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        echo "   ✓ Users table created\n";
        
        // Books table
        $pdo->exec("CREATE TABLE IF NOT EXISTS books (
            id INT AUTO_INCREMENT PRIMARY KEY,
            isbn VARCHAR(20) UNIQUE,
            title VARCHAR(255) NOT NULL,
            author VARCHAR(255) NOT NULL,
            publisher VARCHAR(100),
            publication_year YEAR,
            category VARCHAR(50),
            total_copies INT DEFAULT 1,
            available_copies INT DEFAULT 1,
            location VARCHAR(50),
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_isbn (isbn),
            INDEX idx_title (title),
            INDEX idx_author (author),
            INDEX idx_category (category)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        echo "   ✓ Books table created\n";
        
        // Borrowing records table
        $pdo->exec("CREATE TABLE IF NOT EXISTS borrowing_records (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            book_id INT NOT NULL,
            borrow_date DATE NOT NULL,
            due_date DATE NOT NULL,
            return_date DATE NULL,
            status ENUM('borrowed', 'returned', 'overdue') DEFAULT 'borrowed',
            fine_amount DECIMAL(10,2) DEFAULT 0.00,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
            INDEX idx_user_id (user_id),
            INDEX idx_book_id (book_id),
            INDEX idx_status (status),
            INDEX idx_due_date (due_date)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        echo "   ✓ Borrowing records table created\n\n";
        
        // Step 4: Insert default admin user
        echo "3. Creating default admin user...\n";
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = 'admin'");
        $stmt->execute();
        
        if ($stmt->fetchColumn() == 0) {
            $stmt = $pdo->prepare("
                INSERT INTO users (username, email, password_hash, full_name, role, status) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            
            $passwordHash = password_hash('admin123', PASSWORD_DEFAULT);
            $stmt->execute([
                'admin',
                'admin@library.local',
                $passwordHash,
                'System Administrator',
                'admin',
                'active'
            ]);
            echo "   ✓ Admin user created (username: admin, password: admin123)\n";
        } else {
            echo "   ✓ Admin user already exists\n";
        }
        
        // Step 5: Insert sample books
        echo "\n4. Adding sample books...\n";
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM books");
        $stmt->execute();
        
        if ($stmt->fetchColumn() == 0) {
            $sampleBooks = [
                ['978-0-13-110362-7', 'The C Programming Language', 'Brian Kernighan, Dennis Ritchie', 'Prentice Hall', 1988, 'Programming', 3, 3, 'A-101'],
                ['978-0-321-54374-4', 'Introduction to Algorithms', 'Thomas Cormen', 'MIT Press', 2009, 'Computer Science', 2, 2, 'A-102'],
                ['978-0-596-52068-7', 'JavaScript: The Good Parts', 'Douglas Crockford', "O'Reilly Media", 2008, 'Web Development', 4, 4, 'B-201'],
                ['978-0-134-85391-4', 'Clean Code', 'Robert Martin', 'Prentice Hall', 2008, 'Software Engineering', 5, 5, 'B-202'],
                ['978-1-59327-424-7', 'Python Crash Course', 'Eric Matthes', 'No Starch Press', 2015, 'Programming', 3, 3, 'C-301']
            ];
            
            $stmt = $pdo->prepare("
                INSERT INTO books (isbn, title, author, publisher, publication_year, category, total_copies, available_copies, location) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            foreach ($sampleBooks as $book) {
                $stmt->execute($book);
            }
            echo "   ✓ Sample books added\n";
        } else {
            echo "   ✓ Books already exist\n";
        }
        
        echo "\n🎉 Setup completed successfully!\n\n";
        echo "Database: {$config['dbname']}\n";
        echo "Admin Login:\n";
        echo "  Username: admin\n";
        echo "  Password: admin123\n\n";
        echo "Your AuthDB class should now work perfectly!\n";
        
        return true;
        
    } catch (PDOException $e) {
        echo "❌ Setup failed: " . $e->getMessage() . "\n";
        return false;
    }
}

// Run the setup
quickLibrarySetup();

// Test the connection
echo "\n" . str_repeat("=", 40) . "\n";
echo "Testing AuthDB connection...\n";

class SimpleAuthDB {
    private $conn;
    
    public function __construct() {
        $dsn = "mysql:host=localhost;dbname=library_system;charset=utf8mb4";
        $this->conn = new PDO($dsn, 'root', '', [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
    }
    
    public function testConnection() {
        $stmt = $this->conn->query("SELECT COUNT(*) as user_count FROM users");
        $result = $stmt->fetch();
        return $result['user_count'];
    }
    
    public function getBooks() {
        $stmt = $this->conn->query("SELECT title, author, available_copies FROM books LIMIT 3");
        return $stmt->fetchAll();
    }
}

try {
    $authDB = new SimpleAuthDB();
    $userCount = $authDB->testConnection();
    echo "✓ Connection successful! Found {$userCount} users in database.\n";
    
    $books = $authDB->getBooks();
    echo "✓ Sample books in library:\n";
    foreach ($books as $book) {
        echo "  - {$book['title']} by {$book['author']} ({$book['available_copies']} available)\n";
    }
    
} catch (Exception $e) {
    echo "❌ Connection test failed: " . $e->getMessage() . "\n";
}
?>