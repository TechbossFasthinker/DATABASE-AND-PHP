<?php
session_start();
require_once 'auth_db.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get user data
$stmt = $authDB->conn->prepare("SELECT id, username, email, google_id, created_at FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Profile | Library System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        /* Reusing the same styling */
        :root {
            --primary: #3498db;
            --secondary: #2ecc71;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background: #f5f7fa;
            padding: 2rem;
            margin: 0;
        }
        .profile-container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        h1 {
            color: var(--primary);
            text-align: center;
        }
        .profile-info {
            margin-top: 2rem;
        }
        .info-row {
            display: flex;
            padding: 1rem 0;
            border-bottom: 1px solid #eee;
        }
        .info-label {
            font-weight: 500;
            width: 150px;
            color: #555;
        }
        .info-value {
            flex: 1;
        }
        .google-badge {
            background: #DB4437;
            color: white;
            padding: 0.2rem 0.5rem;
            border-radius: 4px;
            font-size: 0.8rem;
            display: inline-block;
        }
        .logout-btn {
            display: inline-block;
            margin-top: 2rem;
            padding: 0.8rem 1.5rem;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }
        .logout-btn:hover {
            background: #2980b9;
        }
    </style>
</head>
<body>
    <div class="profile-container">
        <h1>Your Profile</h1>
        
        <div class="profile-info">
            <div class="info-row">
                <div class="info-label">Username</div>
                <div class="info-value"><?= htmlspecialchars($user['username']) ?></div>
            </div>
            
            <div class="info-row">
                <div class="info-label">Email</div>
                <div class="info-value"><?= htmlspecialchars($user['email'] ?? 'Not provided') ?></div>
            </div>
            
            <div class="info-row">
                <div class="info-label">Account Type</div>
                <div class="info-value">
                    <?= $user['google_id'] ? '<span class="google-badge">Google Account</span>' : 'Email Account' ?>
                </div>
            </div>
            
            <div class="info-row">
                <div class="info-label">Member Since</div>
                <div class="info-value"><?= date('F j, Y', strtotime($user['created_at'])) ?></div>
            </div>
        </div>
        
        <a href="logout.php" class="logout-btn">Log Out</a>
    </div>
</body>
</html>