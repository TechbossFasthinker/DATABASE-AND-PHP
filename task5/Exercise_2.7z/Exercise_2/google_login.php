<?php
require_once 'vendor/autoload.php'; // Require Google API client
require_once 'auth_db.php';

// Google OAuth configuration
$client = new Google_Client();
//$client->setClientId('637122937896-uqeds8h65hmok0as0ct0a4jc6q3pca1s.apps.googleusercontent.com');
//$client->setClientSecret('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');
//$client->setRedirectUri('http://localhost/task5/Exercise_2/google_auth.php');
$client->addScope('email');
$client->addScope('profile');

// Check if we're receiving a Google auth code
if (isset($_GET['code'])) {
    header("Location: google_auth.php?code=" . $_GET['code']);
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login with Google | Library System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        /* Reusing the same styling from login.php */
        :root {
            --primary: #3498db;
            --error: #e74c3c;
            --success: #2ecc71;
            --google: #DB4437;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background: #f5f7fa;
            padding: 2rem;
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .form-container {
            max-width: 400px;
            width: 100%;
            margin: 0 auto;
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        h1 {
            color: var(--primary);
            text-align: center;
            margin-top: 0;
            margin-bottom: 1.5rem;
        }
        .error {
            color: var(--error);
            margin-bottom: 1rem;
            text-align: center;
            padding: 0.5rem;
            background-color: #fdedee;
            border-radius: 4px;
        }
        .success {
            color: var(--success);
            text-align: center;
            margin-bottom: 1rem;
            padding: 0.5rem;
            background-color: #edf7ee;
            border-radius: 4px;
        }
        .btn {
            width: 100%;
            padding: 0.8rem;
            margin-bottom: 1rem;
            border-radius: 4px;
            cursor: pointer;
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
            transition: background 0.3s ease;
            text-align: center;
            display: block;
            text-decoration: none;
        }
        .btn-google {
            background: var(--google);
            color: white;
            border: none;
        }
        .btn-google:hover {
            background: #c1351d;
        }
        .form-footer {
            text-align: center;
            margin-top: 1rem;
            color: #666;
        }
        a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
        }
        a:hover {
            text-decoration: underline;
        }
        .divider {
            display: flex;
            align-items: center;
            margin: 1rem 0;
        }
        .divider::before, .divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid #ddd;
        }
        .divider-text {
            padding: 0 1rem;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Login with Google</h1>
        
        <!-- Regular login link -->
        <p style="text-align: center;">Or <a href="login.php">login with your account</a></p>
        
        <div class="divider">
            <span class="divider-text">OR</span>
        </div>
        
        <!-- Google login button -->
        <a href="<?= $client->createAuthUrl() ?>" class="btn btn-google">
            <span style="display: flex; align-items: center; justify-content: center;">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="white" style="margin-right: 8px;">
                    <path d="M12.545 10.239v3.821h5.445c-0.712 2.315-2.647 3.972-5.445 3.972-3.332 0-6.033-2.701-6.033-6.032s2.701-6.032 6.033-6.032c1.498 0 2.866 0.549 3.921 1.453l2.814-2.814c-1.786-1.667-4.166-2.716-6.735-2.716-5.522 0-10 4.477-10 10s4.478 10 10 10c8.396 0 10-7.524 10-10 0-0.67-0.069-1.325-0.189-1.955h-9.811z"></path>
                </svg>
                Continue with Google
            </span>
        </a>
        
        <div class="form-footer">
            Don't have an account? <a href="register.php">Register here</a>
        </div>
    </div>
</body>
</html>