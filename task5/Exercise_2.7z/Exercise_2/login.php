<div class="divider">
    <span class="divider-text">OR</span>
</div>

<a href="google_login.php" class="btn btn-google" style="
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 10px 16px;
    background-color: #4285F4;
    color: white;
    border-radius: 4px;
    text-decoration: none;
    font-family: 'Roboto', sans-serif;
    font-size: 14px;
    font-weight: 500;
    box-shadow: 0 2px 4px 0 rgba(0,0,0,0.25);
    transition: background-color 0.3s ease;
    border: none;
    cursor: pointer;
    width: 100%;
    max-width: 240px;
    margin: 8px auto;
">
    <span style="display: flex; align-items: center; justify-content: center;">
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="white" style="margin-right: 12px; background-color: white; padding: 4px; border-radius: 2px;">
            <path d="M12.545 10.239v3.821h5.445c-0.712 2.315-2.647 3.972-5.445 3.972-3.332 0-6.033-2.701-6.033-6.032s2.701-6.032 6.033-6.032c1.498 0 2.866 0.549 3.921 1.453l2.814-2.814c-1.786-1.667-4.166-2.716-6.735-2.716-5.522 0-10 4.477-10 10s4.478 10 10 10c8.396 0 10-7.524 10-10 0-0.67-0.069-1.325-0.189-1.955h-9.811z"></path>
        </svg>
        Continue with Google
    </span>
</a>

<style>
    .divider {
        display: flex;
        align-items: center;
        margin: 20px 0;
        color: #757575;
        font-size: 14px;
    }
    
    .divider::before,
    .divider::after {
        content: "";
        flex: 1;
        border-bottom: 1px solid #e0e0e0;
    }
    
    .divider-text {
        padding: 0 16px;
    }
    
    .btn-google:hover {
        background-color: #3367D6;
        box-shadow: 0 2px 6px 0 rgba(0,0,0,0.25);
    }
    
    .btn-google:active {
        background-color: #2D5DB6;
    }
</style>