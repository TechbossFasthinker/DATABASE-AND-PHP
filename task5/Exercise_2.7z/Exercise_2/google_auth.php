<?php
require_once 'vendor/autoload.php';
require_once 'auth_db.php';
session_start();

// Initialize the AuthDB class
$authDB = new AuthDB();

// Initialize Google Client
$client = new Google_Client();
//$client->setClientId('637122937896-uqeds8h65hmok0as0ct0a4jc6q3pca1s.apps.googleusercontent.com');
//$client->setClientSecret('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');
//$client->setRedirectUri('http://localhost/task5/Exercise_2/google_auth.php');
$client->addScope('email');
$client->addScope('profile');

if (isset($_GET['code'])) {
    try {
        // Exchange authorization code for access token
        $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
        $client->setAccessToken($token);
        
        // Get user info from Google
        $oauth = new Google_Service_Oauth2($client);
        $userInfo = $oauth->userinfo->get();
        
        // Extract user data
        $googleId = $userInfo->getId();
        $email = $userInfo->getEmail();
        $name = $userInfo->getName();
        
        // Check if user exists in database
        $user = $authDB->getUserByGoogleId($googleId);
        if (!$user) {
            $user = $authDB->getUserByEmail($email);
        }
        
        if ($user) {
            // Existing user - log them in
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
        } else {
            // New user - create account
            $username = generateUsername($name);
            
            if (!$authDB->createUser($username, $email, null, $googleId)) {
                throw new Exception("Failed to create user account");
            }
            
            // Get the newly created user
            $user = $authDB->getUserByGoogleId($googleId);
            if (!$user) {
                throw new Exception("Failed to retrieve created user");
            }
            
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
        }
        
        // Redirect to home page after successful login
        header("Location: home.php");
        exit();
        
    } catch (Exception $e) {
        error_log("Google OAuth error: " . $e->getMessage());
        $_SESSION['auth_error'] = "Google authentication failed. Please try again.";
        header("Location: login.php");
        exit();
    }
}

// Regular function (not a class method)
function generateUsername($name) {
    $username = strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $name));
    if (empty($username)) {
        $username = 'user' . bin2hex(random_bytes(3));
    }
    return $username . rand(100, 999);
}

// If no auth code, redirect to Google auth URL
$authUrl = $client->createAuthUrl();
header("Location: " . filter_var($authUrl, FILTER_SANITIZE_URL));
exit();
?>